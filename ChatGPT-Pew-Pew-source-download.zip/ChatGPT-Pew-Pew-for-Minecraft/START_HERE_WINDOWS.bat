@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo ChatGPT Pew Pew for Minecraft - One-click GitHub Import
echo ============================================================
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo Git is not installed or is not on PATH.
  echo Install Git for Windows from https://git-scm.com/download/win
  echo Then double-click this file again.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SYNC_TO_GITHUB.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo The process stopped with an error. The existing main branch was not intentionally changed.
  echo If GitHub authentication failed, sign in when Git asks or retry this file.
) else (
  echo Finished or safely cancelled. Follow any instructions shown above.
)
echo.
pause
exit /b %RESULT%
