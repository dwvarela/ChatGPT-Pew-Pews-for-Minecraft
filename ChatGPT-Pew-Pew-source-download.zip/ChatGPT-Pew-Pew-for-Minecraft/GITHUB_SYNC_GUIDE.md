# GitHub sync and build handoff

The canonical repository is https://github.com/dwvarela/ChatGPT-Pew-Pews-for-Minecraft.
The expanded project in this archive is the intended source of truth. The existing GitHub `main` branch was previously a small M16 starter and must be replaced by this project; a successful build of that starter does **not** validate this mod.

## What this archive preserves

- The recovered mod source and resources under `src/`.
- Original reference JAR and recovered reference assets under `reference/` for comparison.
- GeckoLib animation notes, visual direction, Point Blank NeoForge inspection notes, recovery notes, and offline validators.
- The working feature progress described in `RECOVERY_NOTES.md`.
- A GitHub Actions workflow that validates resource references and attempts a Java 21 Gradle build, then uploads the built JAR.

## Sync this workspace into the repository

Because binary assets are part of the project, the safest route is to sync this archive using Git on a machine that can reach GitHub. Do not copy just the Java files: models, textures, animation JSON, sounds, recipes, and documentation are part of the mod.

1. Extract this archive. Open a terminal in the extracted `ChatGPT-Pew-Pew-for-Minecraft` directory.
2. Clone the existing repository into a separate folder:

   ```sh
   git clone https://github.com/dwvarela/ChatGPT-Pew-Pews-for-Minecraft.git ChatGPT-Pew-Pews-for-Minecraft-github
   ```

3. Copy the contents of this expanded workspace into the cloned repository, replacing the M16 starter files. Preserve the `.git` directory in the clone. On Windows, use Explorer and ensure hidden `.git` remains in the clone; copy the project's visible and hidden files into the clone. On macOS/Linux, from the expanded workspace directory:

   ```sh
   rsync -a --exclude='.git/' ./ ../ChatGPT-Pew-Pews-for-Minecraft-github/
   ```

   The workspace has no `.git` directory, so this copies the full project into the clone without replacing its Git metadata.

4. Review the staged file list and commit/push the project:

   ```sh
   cd ../ChatGPT-Pew-Pews-for-Minecraft-github
   git status --short
   git add -A
   git commit -m "Replace M16 starter with ChatGPT Pew Pew mod workspace"
   git push origin main
   ```

   If your default branch is `master`, use that branch instead. Review the diff before pushing. Do not commit generated `build/` output.

5. Open the Actions tab and inspect the `Build ChatGPT Pew Pew for Minecraft` workflow. The artifact should be named `chatgpt-pew-pew-for-minecraft`.

## Validation status

The offline checks currently pass:

- `python validate_project.py`: 97 active JSON resources, 35 registered item IDs, 16 geometry models, and sound/recipe references checked.
- `python validate_animation_assets.py`: animation assets pass for nine weapon models.

A Gradle compile and in-game test have **not** yet been verified. The first CI run against this complete workspace is the next real build gate. If it fails, use the Actions logs to fix API/compiler issues rather than treating the old M16 build as evidence.

## Project choices that must survive future work

- Target Minecraft Java 1.21.1, NeoForge 21.1.x, Java 21, and GeckoLib 4.9.2.
- Preserve internal mod ID `boltrifle` for resource/recipe compatibility; display name is ChatGPT Pew Pew for Minecraft.
- Use the supplied Point Blank **NeoForge** JAR as an animation-quality/handling benchmark, not as the project's replacement architecture. Do not use the Fabric JAR as the target reference.
- Use the original M14 EBR and M700/Remington 700 assets as project-specific mechanical/modeling references.
- Keep reference attribution and applicable license requirements intact.

## Safer one-command sync helpers

This archive also includes `SYNC_TO_GITHUB.sh` and `SYNC_TO_GITHUB.ps1`. Run the matching script from the extracted workspace directory on a machine with Git and GitHub access. Each script clones the repository into a new sibling directory, creates a dedicated import branch, copies the expanded project while preserving `.git`, and shows the resulting changes for review. The scripts intentionally stop if the target clone directory already exists. Review the file list, then commit and push the branch and open a pull request rather than force-pushing over `main`.
