#!/usr/bin/env python3
"""Validate the weapon animation files expected by the GeckoLib controller."""
import json
from pathlib import Path

ROOT = Path(__file__).parent
ANIM_DIR = ROOT / "src/main/resources/assets/boltrifle/animations/item"
WEAPONS = {
    "bolt_rifle": {"idle", "fire", "dryfire", "reload", "reload_chamber"},
    "ak47": {"idle", "fire", "dryfire", "reload", "reload_chamber"},
    "glock19": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "m14ebr": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "m4a1": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "mini14": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "mp7": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "p90": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
    "sks": {"idle", "fire", "dryfire", "fire_last", "reload", "reload_chamber", "reload_release"},
}

errors = []
for weapon, expected in WEAPONS.items():
    path = ANIM_DIR / f"{weapon}.animation.json"
    if not path.is_file():
        errors.append(f"{weapon}: missing {path.name}")
        continue
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{weapon}: invalid JSON: {exc}")
        continue
    actual = {key.removeprefix(f"animation.{weapon}.") for key in doc.get("animations", {})}
    missing = sorted(expected - actual)
    if missing:
        errors.append(f"{weapon}: missing animations: {', '.join(missing)}")
    for key, animation in doc.get("animations", {}).items():
        if not isinstance(animation, dict) or not isinstance(animation.get("bones", {}), dict):
            errors.append(f"{weapon}: malformed animation {key}")

if errors:
    print("Animation asset validation FAILED")
    print("\n".join(f"- {error}" for error in errors))
    raise SystemExit(1)

print(f"Animation asset validation passed for {len(WEAPONS)} weapon models.")
