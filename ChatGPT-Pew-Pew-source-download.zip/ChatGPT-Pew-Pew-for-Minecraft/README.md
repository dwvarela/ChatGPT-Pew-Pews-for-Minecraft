# ChatGPT Pew Pew for Minecraft

A reconstruction workspace for Minecraft Java 1.21.1 and NeoForge 21.1.x, using Java 21.

## What is included

- The latest source ZIP's basic five-round bolt-action rifle and its server-side hitscan firing/reload logic.
- The supplied `boltrifle.jar` retained under `reference/` for forensic comparison.
- Recovered original item textures, Geo/Blockbench weapon models, animation JSON, sound effects, sound definitions, and recipes.
- Registered item entries for the original weapon catalogue, optics, muzzle attachments, ammunition, magazines, and grenade. Detachable magazines now store their own round counts and only accept their matching caliber.
- GeckoLib 4.9.2 dependency and a generic GeoItem renderer for recovered 3D weapon/attachment models.
- Original rifle sound effects connected to firing and reload actions.

## Build

Requirements: JDK 21, Gradle 8.8+, and an internet connection for the first dependency resolution.

On Windows, run `BUILD_MOD.bat`. On macOS/Linux, run `./BUILD_MOD.sh` (or run the commands below):

```sh
gradle build
```

The JAR should appear in `build/libs/`. A Gradle wrapper is not included yet. The build scripts run both offline resource validators before invoking Gradle. The environment used to prepare this workspace did not have Gradle installed, so a successful compile has **not** been verified here.

## Important status notes

This is an integration/recovery build, not yet a feature-complete restoration of the original compiled mod. The recovered 3D assets are wired to GeckoLib renderers. The bolt-action rifle and the AK-47, Glock 19, M14 EBR, M4A1, Mini-14, MP7, P90, and SKS have basic server-authoritative hitscan firing, caliber-matched ammo consumption, per-stack round counts, cooldowns, and animation triggers. Remaining work includes scoped aiming, attachment fitting/effects, automatic fire modes, grenade entities, broader networking, and in-game testing. Detachable magazines now have round storage, caliber-specific loading, inventory swapping at reload animation beats, and magazine ejection.

The internal mod ID remains `boltrifle` to preserve resource and recipe compatibility. The in-game display name is `ChatGPT Pew Pew for Minecraft`.

## Visual direction

See [`VISUAL_DIRECTION.md`](VISUAL_DIRECTION.md). The M14 EBR and Remington 700 (named `bolt_rifle` internally) from the supplied original mod are the project-specific visual baselines for model detail, proportions, animation timing, and first-person handling. Vic's Point Blank is the quality benchmark for the breadth and polish of the overall weapon experience, not a replacement for those two in-mod references.

## Reference research

The supplied Point Blank **NeoForge** JAR has been inventoried separately. See [`REFERENCE_POINTBLANK_NEOFORGE.md`](REFERENCE_POINTBLANK_NEOFORGE.md) for compatibility findings and the planned architecture. To repeat the offline inventory with Python 3:

```sh
python inspect_reference.py ../pointblank-neoforge-1.21-2.2.0.jar
```


## Animation implementation status

The current animation controller integration and the weapon-specific animation inventory are documented in [`ANIMATION_PIPELINE.md`](ANIMATION_PIPELINE.md). Run `python3 validate_animation_assets.py` to check controller-required animation clips and `python3 validate_project.py` to check resource references, registered item models/names, geometry bone tracks, sounds, and recipes. These offline checks do not replace a Gradle build or in-game testing.
