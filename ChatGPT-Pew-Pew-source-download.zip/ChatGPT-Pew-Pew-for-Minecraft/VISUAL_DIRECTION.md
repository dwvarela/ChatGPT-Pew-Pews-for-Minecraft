# Visual direction: ChatGPT Pew Pew for Minecraft

This brief records the user's explicit visual-reference hierarchy. It is intended to guide future model, animation, and gameplay work.

## 1. Project-specific baseline: the original M14 EBR and Remington 700

Use the M14 EBR and Remington 700 from the supplied original `boltrifle.jar` as the starting point for what this mod's guns should look and feel like. The Remington 700 is named `bolt_rifle` in internal resource paths. Relevant files are:

- `assets/boltrifle/geo/item/m14ebr.geo.json`
- `assets/boltrifle/animations/item/m14ebr.animation.json`
- `assets/boltrifle/geo/item/bolt_rifle.geo.json`
- `assets/boltrifle/animations/item/bolt_rifle.animation.json`
- their corresponding textures, item models, and sound definitions

These are not universal templates that every weapon must copy. They establish the project's desired level of physical readability and animation language: distinct receiver/barrel/stock components, a legible bolt and magazine, articulated hand bones, visible chamber/casing/muzzle-flash elements, and separate idle, firing, dry-fire, and reload states. The M14's reload phases and the Remington 700's manually operated bolt cycle are especially useful references for weapon-specific motion.

## 2. Gold-standard benchmark: Vic's Point Blank

Use the supplied **NeoForge** Point Blank JAR as the gold standard for the overall quality bar: coherent weapon behavior, data-driven definitions, robust animation state transitions, attachment support, sound integration, and consistency across the arsenal. The target is to learn from its results and architecture while building a maintainable implementation for this mod, not to assume Point Blank's internal JSON or classes can simply be dropped into this codebase.

## 3. Real-world reference photos

Use the supplied firearm and attachment photos as supporting reference for proportions, silhouettes, materials, sight placement, muzzle devices, and magazine geometry. They supplement the in-game models rather than override the M14/Remington 700 baseline or Point Blank's overall quality benchmark.

## 4. Practical acceptance criteria

For each weapon, evaluate:

- **Silhouette:** recognizable profile and believable relative proportions in first person and inventory views.
- **Construction:** receiver, barrel, stock/grip, magazine, sights, bolt/charging handle, and muzzle device read as distinct parts where appropriate.
- **Materials:** controlled contrast between metal, polymer, wood, optics, and small controls; avoid a single flat texture across the whole gun.
- **Motion:** recoil returns to a stable pose; moving parts animate independently; reloads have clear hand-to-magazine/action contact; the timing fits the actual weapon mechanism.
- **State clarity:** idle, firing, dry-fire, reload, final-round, bolt/action, and attachment states do not conflict or leave parts stranded.
- **Feedback:** sounds, casing/muzzle effects, and animation events line up rather than firing at arbitrary times.
- **Consistency:** weapons share a common presentation quality without losing their own operating mechanisms.

## 5. Scope and provenance

The M14 EBR and Remington 700 assets are the user's existing project references. Point Blank is an authorized reference according to the user's stated permission and tutorial context. Preserve any attribution or licensing conditions that the respective author specified. Keep namespaces and resource paths separate, and implement compatible behavior deliberately rather than blindly copying runtime internals.

## Current limitation

This brief documents direction; it does not claim that every weapon's animations or mechanics are already wired or tested. The current workspace still requires a successful Gradle build and in-game verification.
