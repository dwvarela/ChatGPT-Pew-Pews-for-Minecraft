@echo off
setlocal
where java >nul 2>nul || (echo ERROR: Java was not found. Install JDK 21 first.& pause & exit /b 1)
java -version 2>&1 | findstr /C:"21." >nul || echo WARNING: This project targets Java 21. Confirm that JAVA_HOME points to JDK 21.
python validate_animation_assets.py || (echo ERROR: Animation validation failed.& pause & exit /b 1)
python validate_project.py || (echo ERROR: Resource validation failed.& pause & exit /b 1)
where gradle >nul 2>nul || (echo ERROR: Gradle was not found. Install Gradle 8.8 or newer, or open this folder in IntelliJ IDEA with Gradle support.& pause & exit /b 1)
gradle build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the complete error output before changing code.
  pause
  exit /b 1
)
echo.
echo BUILD COMPLETE. Look in build\libs for chatgpt-pew-pew-for-minecraft-0.2.0.jar
pause
