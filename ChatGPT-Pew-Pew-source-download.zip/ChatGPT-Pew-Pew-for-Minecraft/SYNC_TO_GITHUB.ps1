$ErrorActionPreference = 'Stop'
$RepoUrl = 'https://github.com/dwvarela/ChatGPT-Pew-Pews-for-Minecraft.git'
$CloneDir = Join-Path (Get-Location).Path '..\ChatGPT-Pew-Pews-for-Minecraft-github'
$Branch = 'import/expanded-chatgpt-pew-pew'
$SourceDir = (Get-Location).Path

if (Test-Path $CloneDir) {
    throw "Refusing to overwrite existing path: $CloneDir. Rename it or edit CloneDir in this script."
}

git clone $RepoUrl $CloneDir
if ($LASTEXITCODE -ne 0) { throw 'Git could not clone the repository. Check your internet connection and GitHub access.' }
Push-Location $CloneDir
try {
    git switch -c $Branch
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the import branch.' }

    # Replace starter-project files on this new branch, preserving .git and history.
    Get-ChildItem -Force $CloneDir | Where-Object { $_.Name -ne '.git' } | Remove-Item -Recurse -Force
    Get-ChildItem -Force $SourceDir | Where-Object {
        $_.Name -notin @('.git', '.gradle', 'build', '.idea') -and $_.Extension -ne '.iml'
    } | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination $CloneDir -Recurse -Force
    }

    Write-Host ''
    Write-Host 'Reviewing the proposed project import. The main branch has NOT been changed.' -ForegroundColor Cyan
    git status --short
    Write-Host ''
    $answer = Read-Host 'If this looks right, type YES to commit and upload the new branch to GitHub'
    if ($answer -cne 'YES') {
        Write-Host 'Stopped safely. The prepared files remain in:' $CloneDir
        return
    }

    # Set identity only for this local import commit; GitHub authentication remains Git's normal prompt.
    git config user.name 'ChatGPT Pew Pew Workspace Import'
    git config user.email 'noreply@github.com'
    git add -A
    if ($LASTEXITCODE -ne 0) { throw 'Could not stage the project files.' }
    git commit -m 'Import expanded ChatGPT Pew Pew mod workspace'
    if ($LASTEXITCODE -ne 0) { throw 'Commit failed. No branch was uploaded.' }
    git push -u origin $Branch
    if ($LASTEXITCODE -ne 0) { throw 'Upload failed. The local branch is saved; check GitHub sign-in and try pushing from the prepared folder.' }

    $PrUrl = 'https://github.com/dwvarela/ChatGPT-Pew-Pews-for-Minecraft/compare/main...' + $Branch + '?expand=1'
    Write-Host ''
    Write-Host 'Upload complete. The existing main branch is unchanged.' -ForegroundColor Green
    Write-Host 'Opening the page to create the pull request:' $PrUrl
    Start-Process $PrUrl
}
finally { Pop-Location }
