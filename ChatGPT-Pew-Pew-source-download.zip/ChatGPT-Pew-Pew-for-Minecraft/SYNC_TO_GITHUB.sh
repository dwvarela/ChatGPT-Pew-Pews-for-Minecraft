#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(pwd)"
REPO_URL="https://github.com/dwvarela/ChatGPT-Pew-Pews-for-Minecraft.git"
CLONE_DIR="../ChatGPT-Pew-Pews-for-Minecraft-github"
BRANCH="import/expanded-chatgpt-pew-pew"

if [[ -e "$CLONE_DIR" ]]; then
  echo "Refusing to overwrite existing path: $CLONE_DIR" >&2
  echo "Rename/remove it yourself, or edit CLONE_DIR in this script." >&2
  exit 2
fi

git clone "$REPO_URL" "$CLONE_DIR"
cd "$CLONE_DIR"
git switch -c "$BRANCH"

# Sync the expanded project into the clone, preserving its .git metadata.
# Exclude generated outputs and local IDE/cache files if they appear.
rsync -a --delete \
  --exclude='.git/' \
  --exclude='.gradle/' \
  --exclude='build/' \
  --exclude='.idea/' \
  --exclude='*.iml' \
  "$SOURCE_DIR/" ./

echo
echo "Review the proposed import before committing:"
git status --short
echo
echo "If the file list looks right, run:"
echo "  git add -A"
echo "  git commit -m 'Import expanded ChatGPT Pew Pew mod workspace'"
echo "  git push -u origin $BRANCH"
echo "Then open a PR from '$BRANCH' into main and inspect the Actions build."
