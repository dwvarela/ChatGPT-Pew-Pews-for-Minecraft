package com.example.boltrifle;

import java.util.List;
import java.util.function.Supplier;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Server-authoritative hitscan firearm that swaps compatible, individually loaded magazine items. */
public class FirearmItem extends GeoModelItem {
    private final Supplier<? extends MagazineItem> magazineItem;
    private final int magazineSize;
    private final float damage;
    private final double range;
    private final int shotCooldown;
    private final Supplier<SoundEvent> shotSound;

    public FirearmItem(Properties properties, String geoName, String textureName,
                       Supplier<? extends MagazineItem> magazineItem, int magazineSize,
                       float damage, double range, int shotCooldown, Supplier<SoundEvent> shotSound) {
        super(properties, geoName, textureName);
        this.magazineItem = magazineItem;
        this.magazineSize = magazineSize;
        this.damage = damage;
        this.range = range;
        this.shotCooldown = shotCooldown;
        this.shotSound = shotSound;
    }

    private int loaded(ItemStack stack) {
        return Mth.clamp(stack.getOrDefault(BoltRifleMod.LOADED.get(), 0), 0, magazineSize);
    }

    public MagazineItem getMagazineItem() {
        return magazineItem.get();
    }

    public int getMagazineCapacity() {
        return magazineSize;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.consume(stack);
        // Do not allow repeated use packets to restart a reload and overwrite its reserved rounds.
        if (BoltRifleMod.isReloading(stack)) return InteractionResultHolder.consume(stack);
        if (player.isShiftKeyDown() || loaded(stack) == 0) return reload(level, player, stack);
        return fire(level, player, stack);
    }

    private InteractionResultHolder<ItemStack> fire(Level level, Player player, ItemStack stack) {
        int rounds = loaded(stack);
        triggerWeaponAnimation(level, player, stack, rounds == 1 ? "fire_last" : "fire");
        stack.set(BoltRifleMod.LOADED.get(), rounds - 1);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), shotSound.get(),
                SoundSource.PLAYERS, 1.0f, 0.92f + level.random.nextFloat() * 0.16f);

        Vec3 start = player.getEyePosition();
        Vec3 direction = player.getViewVector(1.0f);
        Vec3 end = start.add(direction.scale(range));
        BlockHitResult blockHit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getLocation();
        AABB box = player.getBoundingBox().expandTowards(direction.scale(range)).inflate(1.0);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(level, player, start, limit, box,
                entity -> !entity.isSpectator() && entity.isAttackable() && entity.isPickable());
        Vec3 impact = limit;
        if (entityHit != null) {
            Entity target = entityHit.getEntity();
            impact = entityHit.getLocation();
            target.hurt(level.damageSources().playerAttack(player), damage);
        }
        if (level instanceof ServerLevel server) {
            Vec3 delta = impact.subtract(start);
            double length = delta.length();
            Vec3 step = delta.normalize().scale(1.25);
            for (double d = 0; d < length; d += 1.25) {
                server.sendParticles(ParticleTypes.CRIT, start.x + step.x * d / 1.25,
                        start.y + step.y * d / 1.25, start.z + step.z * d / 1.25, 1, 0, 0, 0, 0);
            }
            server.sendParticles(ParticleTypes.SMOKE, impact.x, impact.y, impact.z, 3, 0.04, 0.04, 0.04, 0.01);
        }
        player.getCooldowns().addCooldown(this, shotCooldown);
        if (rounds == 1) player.displayClientMessage(Component.literal("Magazine empty. Sneak + right-click to swap magazines.").withStyle(ChatFormatting.YELLOW), true);
        return InteractionResultHolder.success(stack);
    }

    private InteractionResultHolder<ItemStack> reload(Level level, Player player, ItemStack stack) {
        int rounds = loaded(stack);
        boolean emptyReload = rounds == 0;
        int pendingRounds;

        if (player.isCreative()) {
            pendingRounds = magazineSize;
        } else {
            Inventory inventory = player.getInventory();
            ItemStack loadedMagazine = ItemStack.EMPTY;
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                ItemStack candidate = inventory.getItem(i);
                if (candidate.is(magazineItem.get())
                        && candidate.getOrDefault(BoltRifleMod.MAG_LOADED.get(), 0) > 0) {
                    loadedMagazine = candidate;
                    break;
                }
            }
            if (loadedMagazine.isEmpty()) {
                player.displayClientMessage(Component.literal("No loaded compatible magazine. Hold a magazine and right-click to load it with matching ammunition.")
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResultHolder.fail(stack);
            }
            pendingRounds = magazineItem.get().loaded(loadedMagazine);
            loadedMagazine.shrink(1);
            inventory.setChanged();
        }

        triggerWeaponAnimation(level, player, stack, emptyReload ? "reload_chamber" : "reload");
        int reloadTicks = reloadCooldownTicks(emptyReload);
        BoltRifleMod.beginReload(stack, pendingRounds, reloadTicks);
        player.getCooldowns().addCooldown(this, reloadTicks);
        player.displayClientMessage(Component.literal("Reloading magazine...").withStyle(ChatFormatting.GREEN), true);
        return InteractionResultHolder.success(stack);
    }

    private int reloadCooldownTicks(boolean emptyReload) {
        // Match the lockout to the authored animation duration (seconds * 20 ticks).
        return switch (getGeoName()) {
            case "glock19" -> emptyReload ? 52 : 34;
            case "m4a1", "mini14" -> emptyReload ? 59 : 40;
            case "mp7" -> emptyReload ? 57 : 38;
            case "p90" -> emptyReload ? 67 : 48;
            case "sks" -> emptyReload ? 63 : 44;
            default -> emptyReload ? 68 : 46;
        };
    }

    @Override public boolean isBarVisible(ItemStack stack) { return true; }
    @Override public int getBarWidth(ItemStack stack) { return Mth.clamp(Math.round(13.0f * loaded(stack) / magazineSize), 0, 13); }
    @Override public int getBarColor(ItemStack stack) { return loaded(stack) == 0 ? 0xCC3333 : 0xE0A030; }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Loaded: " + loaded(stack) + "/" + magazineSize).withStyle(ChatFormatting.GRAY));
        if (BoltRifleMod.isReloading(stack)) {
            tooltip.add(Component.literal("Reloading...").withStyle(ChatFormatting.YELLOW));
        }
        tooltip.add(Component.literal("Right-click: fire").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.literal("Sneak + right-click: swap compatible magazine").withStyle(ChatFormatting.DARK_GRAY));
    }
}
