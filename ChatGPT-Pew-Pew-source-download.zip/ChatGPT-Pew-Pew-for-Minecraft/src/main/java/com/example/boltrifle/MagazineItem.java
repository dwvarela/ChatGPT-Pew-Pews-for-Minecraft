package com.example.boltrifle;

import java.util.List;
import java.util.function.Supplier;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.util.Mth;

/** A detachable magazine that stores its own rounds and only accepts one matching ammunition type. */
public final class MagazineItem extends Item {
    private final Supplier<? extends Item> ammoItem;
    private final int capacity;

    public MagazineItem(Properties properties, Supplier<? extends Item> ammoItem, int capacity) {
        super(properties.stacksTo(1));
        this.ammoItem = ammoItem;
        this.capacity = capacity;
    }

    public int capacity() {
        return capacity;
    }

    public int loaded(ItemStack stack) {
        return Mth.clamp(stack.getOrDefault(BoltRifleMod.MAG_LOADED.get(), 0), 0, capacity);
    }

    public Item ammoItem() {
        return ammoItem.get();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack magazine = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.consume(magazine);

        int current = loaded(magazine);
        int needed = capacity - current;
        if (needed <= 0) {
            player.displayClientMessage(Component.literal("Magazine full: " + current + "/" + capacity)
                    .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(magazine);
        }

        int added = 0;
        if (player.isCreative()) {
            added = needed;
        } else {
            Inventory inventory = player.getInventory();
            for (int slotIndex = 0; slotIndex < inventory.getContainerSize() && added < needed; slotIndex++) {
                ItemStack stack = inventory.getItem(slotIndex);
                if (stack == magazine || !stack.is(ammoItem.get())) continue;
                int take = Math.min(stack.getCount(), needed - added);
                stack.shrink(take);
                added += take;
            }
            if (added > 0) inventory.setChanged();
        }

        if (added <= 0) {
            player.displayClientMessage(Component.literal("Needs matching ammunition: " + ammoItem.get().getDescription().getString())
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(magazine);
        }

        magazine.set(BoltRifleMod.MAG_LOADED.get(), current + added);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), BoltRifleMod.CLICK.get(),
                SoundSource.PLAYERS, 0.65f, 0.95f + level.random.nextFloat() * 0.1f);
        player.displayClientMessage(Component.literal("Loaded magazine: " + (current + added) + "/" + capacity)
                .withStyle(ChatFormatting.GREEN), true);
        return InteractionResultHolder.success(magazine);
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Mth.clamp(Math.round(13.0f * loaded(stack) / capacity), 0, 13);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return loaded(stack) == 0 ? 0xCC3333 : 0xE0A030;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Rounds: " + loaded(stack) + "/" + capacity).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Right-click: load with matching ammo").withStyle(ChatFormatting.DARK_GRAY));
    }
}
