#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

command -v java >/dev/null 2>&1 || { echo "ERROR: Java 21 is required." >&2; exit 1; }
java -version 2>&1 | grep -Eq 'version "21\.' || { echo "ERROR: This project targets Java 21. Select a Java 21 JDK." >&2; exit 1; }

python3 validate_animation_assets.py
python3 validate_project.py

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle was not found. Install Gradle 8.8+ or open this project in an IDE with Gradle support." >&2
  echo "The offline resource checks passed, but Java compilation has NOT been run." >&2
  exit 2
fi

gradle build
printf '\nBUILD COMPLETE. Output: build/libs/chatgpt-pew-pew-for-minecraft-%s.jar\n' "$(sed -n 's/^mod_version=//p' gradle.properties | head -1)"
