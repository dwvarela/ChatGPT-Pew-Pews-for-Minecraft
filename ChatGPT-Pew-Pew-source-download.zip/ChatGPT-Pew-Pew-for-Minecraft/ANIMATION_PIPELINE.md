# Weapon animation integration plan and current implementation

## Reference priority

1. **Vic's Point Blank NeoForge** is the animation-system quality benchmark: clear draw/idle/fire/inspect/reload states, empty-versus-tactical reload differences, articulated parts, and reliable state transitions.
2. The project's own **M14 EBR** and **Remington 700** establish its weapon-specific realism: readable operating parts, believable bolt/charging motion, hand-to-magazine contact, and animations that match each weapon's mechanism.
3. Real-world photos ground proportions and the mechanics represented by the model.

Point Blank's animation names and runtime aren't copied into the project's controller. Its supplied item definitions use a separate `animation.model.*` naming scheme and runtime state machine; our existing GeckoLib assets use `animation.<weapon>.*`. This integration deliberately keeps the existing model and animation assets intact and maps gameplay events to those authored animations.

## Implemented in this pass

- Added a GeckoLib `weapon` controller for the nine animated weapon models already present in this workspace: bolt rifle, AK-47, Glock 19, M14 EBR, M4A1, Mini-14, MP7, P90, and SKS.
- Added synced trigger names for idle, fire, dry fire, tactical reload, and empty reload/chambering. The last-shot animation is selected for models that actually contain it, with a safe fire-animation fallback for the AK-47 and bolt rifle.
- Hooked firing and reload events in `FirearmItem` and `RifleItem` to the controller.
- Set reload cooldowns to roughly track the authored animation lengths, so the weapon does not become usable halfway through a longer reload animation.
- Kept attachments out of the weapon controller because their animation JSON files are empty.
- Aligned the bolt rifle's fire cooldown more closely with its authored 1.6-second bolt-cycle animation.

## Current animation inventory

| Weapon | Idle | Fire | Last shot | Tactical reload | Empty reload/chamber | Release variant |
|---|---|---|---|---|---|---|
| Bolt rifle / Remington 700 | Yes | Yes | No | Yes | Yes | No |
| AK-47 | Yes | Yes | No | Yes | Yes | No |
| Glock 19 | Yes | Yes | Yes | Yes | Yes | Yes |
| M14 EBR | Yes | Yes | Yes | Yes | Yes | Yes |
| M4A1 | Yes | Yes | Yes | Yes | Yes | Yes |
| Mini-14 | Yes | Yes | Yes | Yes | Yes | Yes |
| MP7 | Yes | Yes | Yes | Yes | Yes | Yes |
| P90 | Yes | Yes | Yes | Yes | Yes | Yes |
| SKS | Yes | Yes | Yes | Yes | Yes | Yes |

## Known next steps

- Run a real Gradle build against Minecraft 1.21.1, NeoForge 21.1.257, Java 21, and GeckoLib 4.9.2. This environment has Java 21 but no Gradle executable or wrapper, so compilation remains unverified.
- Test first-person, third-person, inventory, offhand, and multiplayer animation synchronization in-game.
- Use animation keyframes to time sound events rather than playing every reload sound at the start of the interaction.
- Implement a staged reload state machine if testing shows that visual animation timing and ammunition state need to change at distinct points during the reload.
- Add inspect/draw/holster states and weapon-specific handling for bolt-action versus magazine-fed weapons.
- Review attachment compatibility and model mount points after the base weapon animation path is stable.


## Staged reload implementation

Reload handling now reserves ammunition when a reload starts, then commits it when the reload timeline reaches the magazine-in beat. Sound stages are spread across the cooldown: magazine-out near 20%, magazine-in near 48%, and rack/bolt-close near 78%. The server ticks this state on the stack and applies a completion safety net. These are initial timing heuristics, not a substitute for measuring each animation's actual keyframe times in-game.


## Bolt-action sound and animation timing pass

- Connected the Remington 700 / `bolt_rifle` item to its authored `fire`, `reload`, and `reload_chamber` animations. The previous code path played the shot and both bolt sounds at the same instant and did not trigger the rifle's fire/reload animation controller.
- Added a separate server-side bolt-cycle timeline. The shot sound plays at fire time; bolt-open and bolt-close sounds are scheduled at 34% and 72% of the 32-tick cycle, respectively. These are deliberate first-pass timing estimates and should be tuned against the animation in-game.
- The reload animation selection now distinguishes a partial/tactical reload from an empty reload/chambering sequence.


## Latest safety/mechanics pass

- Reload input is now rejected while a reload timeline is active, preventing duplicate reload starts and lost/overwritten pending ammunition.
- The bolt-action rifle rejects input while its bolt-cycle timeline is active.
- Reload sound beats distinguish detachable-magazine firearms from the M700's internal-magazine operation. The M700 uses bolt-open, handling-click, and bolt-close beats; magazine-fed weapons keep mag-out, mag-in, and rack sounds.
- Tooltips indicate reload/chambering or bolt-working state. These UI states reflect the server-synchronized item components.


## Magazine-state synchronization

Detachable-magazine weapons now use a two-stage inventory transaction aligned with the reload animation: the selected compatible magazine is reserved at reload start, the installed magazine is returned to inventory at the mag-out beat, and the reserved magazine's rounds become the weapon's loaded count at mag-in. Magazine items store their own round count and load from matching loose ammunition by right-clicking while held. The M700 remains a fixed internal-magazine design and uses loose rifle rounds instead. Exact beat positions are estimates until checked against the authored keyframes in-game.
