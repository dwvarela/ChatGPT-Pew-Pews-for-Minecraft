# Point Blank NeoForge reference notes

This document records the inspection of `pointblank-neoforge-1.21-2.2.0.jar`. It is a design/compatibility reference for **ChatGPT Pew Pew for Minecraft**, not a claim that Point Blank's implementation has been ported.

## Confirmed from the supplied JAR

- This is the **NeoForge** build, mod ID `pointblank`, version `2.2.0`.
- Its metadata targets Minecraft `1.21` through versions below `1.21.2`, NeoForge `[21.0,21.3)`, and GeckoLib `[4.9.2,)`.
- It includes 61 declarative item definitions, 151 item Geo models, 68 item animation files, 226 item textures, and 395 sound definitions.
- Its `ak47` item definition demonstrates data-driven weapon configuration: magazine capacity, damage, rounds per minute, recoil values, fire modes, compatible ammo, attachment groups, compatible attachments, conditional features, phased reloads, inspect/idle/draw animations, and effects.
- The Java package layout separates item logic, registries, networking, client rendering/state, features, entities, attachments, inventory/menu handling, and platform-specific NeoForge integration.
- The supplied JAR metadata says `license="All Rights Reserved"` and contains no obvious bundled license/notice file. The user's stated author permission and tutorial context should be kept with the project records, and any attribution/conditions the author specified should be followed.

## Compatibility notes

- This project targets Minecraft 1.21.1 / NeoForge 21.1.x, which falls inside the reference JAR's declared Minecraft and NeoForge ranges.
- The project now declares GeckoLib `4.9.2`, matching the version the user has confirmed works with both the project and the NeoForge Point Blank reference. This is a deliberate dependency choice, not a reason to copy the reference JAR's classes into this project.
- The reference's item definitions and model display JSON provide useful examples, but its custom item loader (`forge:separate_transforms`), runtime registries, network packets, and mixins are part of Point Blank's own architecture. Those formats do not become active merely by copying their JSON into this mod.
- Keep namespaces distinct: this project currently uses `boltrifle` for registry/resource compatibility; the reference uses `pointblank`. Never overwrite this project's resources with `pointblank` paths by accident.

## Visual-reference hierarchy

- **Primary in-project art references:** the original mod's M14 EBR (`m14ebr.geo.json` / `m14ebr.animation.json`) and Remington 700 (`bolt_rifle.geo.json` / `bolt_rifle.animation.json`). These are the specific models and animations the user identified as the desired visual direction.
- **Quality benchmark:** Vic's Point Blank NeoForge build, for system depth, consistency, presentation, and overall polish. Do not treat its assets or architecture as the sole visual target.
- **Independent firearm reference photos:** use the supplied firearm and attachment photos for real-world shape, materials, and attachment placement.

## Recommended implementation order

1. Get the current NeoForge workspace building with a reproducible JDK 21 / Gradle setup.
2. Stabilize item registration, persistent per-stack ammo state, and server-authoritative firing/reload behavior.
3. Implement a shared weapon definition/configuration layer (capacity, ammo item, damage, range, RPM/cooldown, fire modes, reload timing, sound keys).
4. Implement actual magazine items and caliber matching, then attachment slots/compatibility and their gameplay effects.
5. Wire animation controllers to explicit states/events: draw, fire, reload phases, inspect, and attachment changes.
6. Add client/server packets only where needed; validate all gameplay decisions server-side.
7. Test a dedicated server and client, then document the author permission/attribution and the project's own licensing.

## Validation performed

- The supplied NeoForge JAR opened successfully as a ZIP archive and its NeoForge metadata was read.
- All 97 JSON files in the current workspace's active `src/main/resources` tree parse successfully.
- No Gradle executable or Gradle wrapper is currently present in this environment, so compilation and an in-game test have **not** been verified.
