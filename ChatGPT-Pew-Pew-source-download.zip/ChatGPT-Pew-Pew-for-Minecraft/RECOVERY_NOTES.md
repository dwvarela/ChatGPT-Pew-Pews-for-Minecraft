# Recovery and integration notes

Target runtime: Minecraft Java 1.21.1, NeoForge 21.1.x, Java 21, GeckoLib 4.9.2.

## Inputs
- `src/` is based on the latest uploaded `Bolt-Rifle-Test-main.zip`.
- `reference/boltrifle-original.jar` is the richer supplied compiled mod (Bolt Action Rifle 2.0.0).
- `reference/original-jar-assets/` preserves the original compiled mod's asset tree for inspection.

## Work completed in this pass
- Copied the original mod's 3D geo models, textures, animations, item models, language strings, and sound assets into active resources.
- Restored recipes from the original JAR.
- Added GeckoLib 4.9.2 to the Gradle dependencies and declared it as a required mod dependency.
- Added generic GeckoLib item rendering for the recovered weapon/attachment geometry.
- Registered the original weapon, ammo, magazine, attachment, and grenade catalogue.
- Added hitscan firing, caliber-matched ammo consumption, reload, magazine counts, cooldowns, particles, and original sound effects for the AK-47, Glock 19, M14 EBR, M4A1, Mini-14, MP7, P90, and SKS.
- Kept the five-round bolt-action rifle prototype and connected its firing/reload actions to original sound assets.
- Changed the display name and build archive name to ChatGPT Pew Pew for Minecraft while retaining the `boltrifle` namespace for asset/recipe compatibility.

## Not yet complete / verified
- The original compiled mod's full Java behavior has not been recovered. In particular, animated reload/chambering, scoped aiming, attachment fitting and per-attachment effects, magazine swapping, fire-mode controls, grenade entity behavior, and original network payload handling are not implemented yet.
- The environment used for this pass does not have Gradle installed and cannot reach the distribution host, so a Gradle compile or in-game smoke test could not be run. Treat the source as an integration build requiring a real Gradle build and test before installing in a world.


## Latest implementation pass

- Added a synced GeckoLib weapon controller for the nine animated weapon models and connected fire/dry-fire/reload interactions to animation triggers.
- Reload cooldowns now approximate the authored animation lengths; the bolt rifle cooldown aligns with its 1.6-second fire/bolt-cycle animation.
- Added `ANIMATION_PIPELINE.md` and `validate_animation_assets.py`. The asset validator passes for all nine weapon models, and all 97 active resource JSON files parse.
- Compilation and runtime synchronization remain unverified because this workspace has no Gradle executable or wrapper.


## Build-readiness audit

- Added `validate_project.py`, an offline resource-integrity check covering JSON syntax, registered-item model/name coverage, item-model texture references, GeckoLib geometry/animation bone names, sound-file references, and recipe item IDs.
- The audit currently passes: 97 JSON resources, 35 registered item IDs, 16 geometry models, and sound/recipe references.
- Fixed the Remington 700 / bolt-rifle reload lockout to match its authored animation lengths: 58 ticks for the 2.9-second tactical reload and 82 ticks for the 4.1-second empty reload/chamber sequence.
- Gradle compilation is still blocked in this environment because Gradle is not installed and the Gradle distribution host cannot be reached.


## Staged reload pass

- Added per-stack reload timeline components for ticks remaining, total duration, reserved rounds, and one-shot sound stage flags.
- Reload sounds are now emitted at staged beats (magazine out, magazine in, then rack/bolt-close) rather than all at reload start.
- Reserved ammunition is committed to the weapon's loaded-round count at the magazine-in beat, with a completion safety net so the rounds are not lost if a stage is skipped.
- Reload state ticks server-side and follows the weapon stack through the player's inventory, allowing the timer to keep advancing if the player changes slots.
- This remains an approximation driven by authored clip duration; precise per-weapon keyframe timestamps and in-game interruption behavior still need verification.


## Bolt-action animation timing pass

- Fixed a missing connection in `RifleItem`: the Remington 700 now triggers its `fire`, `reload`, and `reload_chamber` GeckoLib animations.
- Removed the simultaneous bolt-open and bolt-close sounds from the firing instant. A server-ticked, per-stack bolt-cycle timeline plays them at 34% and 72% of the bolt cooldown.
- Added three persistent/network-synchronized item data components for the bolt-cycle timeline. These changes are statically inspected but still require Gradle compilation and in-game timing validation.


## Reload-state safety and M700 mechanical audio pass

- Added server-side guards in both weapon `use` paths so repeated use packets cannot restart an in-progress reload and overwrite the reserved ammunition timeline.
- Added an explicit M700 bolt-cycle guard so firing/reload interactions are not accepted while its bolt-cycle timeline is active.
- Item tooltips now show a reload/chambering state, and the M700 shows a working-bolt state while its cycle is active.
- Made reload sounds weapon-specific: magazine-fed firearms retain magazine-out/magazine-in/rack beats; the M700 uses bolt-open/handling-click/bolt-close beats because it has an internal magazine.
- Extended the offline validator with static checks for these guards and sound-path selection.
- Resource validation passes, but Gradle compilation and in-game testing remain outstanding.


## Detachable-magazine implementation pass

- Added `MagazineItem`, which stores rounds in the `mag_loaded` data component, shows a durability-style ammo bar, and loads only from its configured ammunition item when right-clicked.
- Connected AK-47, Glock 19, M14 EBR, M4A1, Mini-14, MP7, P90, and SKS to their compatible magazine item. The M700 remains an internal-magazine rifle and continues to load loose rifle rounds.
- Firearm reload now reserves a loaded compatible magazine, ejects the currently installed magazine at the mag-out animation beat, and inserts the reserved round count at the mag-in beat. Ejected magazines retain their rounds; if inventory insertion fails, the magazine is dropped.
- Creative reloads use a full magazine without consuming inventory.
- Updated `validate_project.py` to recognize helper-registered magazine items and check core magazine/reload wiring.
- Still requires a Gradle compile and in-game validation; offline source/resource checks cannot prove API compatibility or gameplay behavior.
