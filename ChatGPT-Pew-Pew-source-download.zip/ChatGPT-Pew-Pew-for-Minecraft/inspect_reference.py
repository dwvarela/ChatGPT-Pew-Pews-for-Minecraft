"""Small offline inventory helper for the supplied Point Blank NeoForge reference JAR."""
from collections import Counter
from pathlib import Path
import json
import sys
import zipfile

jar = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("../pointblank-neoforge-1.21-2.2.0.jar")
if not jar.is_file():
    raise SystemExit(f"Reference JAR not found: {jar}")
with zipfile.ZipFile(jar) as archive:
    names = archive.namelist()
    metadata = archive.read("META-INF/neoforge.mods.toml").decode("utf-8", "replace")
    sounds = json.loads(archive.read("assets/pointblank/sounds.json"))
    item_definitions = [n for n in names if n.startswith("data/pointblank/items/") and n.endswith(".json")]
    categories = {
        "item Geo models": "assets/pointblank/geo/item/",
        "item animations": "assets/pointblank/animations/item/",
        "item textures": "assets/pointblank/textures/item/",
    }
    print(f"Reference: {jar.resolve()}")
    for line in metadata.splitlines():
        if any(key in line for key in ('modId=', 'version=', 'displayName=', 'license=', 'versionRange=', 'modId="geckolib"')):
            print(line.strip())
    print(f"Declarative item definitions: {len(item_definitions)}")
    for label, prefix in categories.items():
        suffix = {"item Geo models": ".geo.json", "item animations": ".animation.json", "item textures": ".png"}[label]
        print(f"{label}: {sum(n.startswith(prefix) and n.endswith(suffix) for n in names)}")
    print(f"Sound definitions: {len(sounds)}")
    print("Sample item definitions:", ", ".join(Path(n).stem for n in item_definitions[:12]))
