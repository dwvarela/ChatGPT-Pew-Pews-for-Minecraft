#!/usr/bin/env python3
"""Offline resource-integrity checks for ChatGPT Pew Pew for Minecraft.

This script does not replace Gradle compilation or Minecraft runtime testing.
It checks JSON syntax and common broken resource references before a build.
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RES = ROOT / "src/main/resources"
ASSETS = RES / "assets/boltrifle"
JAVA = ROOT / "src/main/java/com/example/boltrifle/BoltRifleMod.java"
errors: list[str] = []
checks = 0


def load_json(path: Path):
    global checks
    checks += 1
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {path.relative_to(ROOT)}: {exc}")
        return None

# 1. Parse every resource JSON.
json_docs: dict[Path, object] = {}
for path in sorted(RES.rglob("*.json")):
    doc = load_json(path)
    if doc is not None:
        json_docs[path] = doc

# 2. Recover the declared item IDs from registration source and verify models/lang.
source = JAVA.read_text(encoding="utf-8") if JAVA.exists() else ""
registered = set(re.findall(r'ITEMS\.register\("([a-z0-9_]+)"', source))
# The registration helpers take their ID from a field/helper argument; collect those too.
registered.update(re.findall(r'firearm\("([a-z0-9_]+)"', source))
registered.update(re.findall(r'geo\("([a-z0-9_]+)"', source))
registered.update(re.findall(r'magazine\("([a-z0-9_]+)"', source))
registered.update(re.findall(r'item\("([a-z0-9_]+)"', source))
lang_path = ASSETS / "lang/en_us.json"
lang = json_docs.get(lang_path, {})
for item_id in sorted(registered):
    model = ASSETS / f"models/item/{item_id}.json"
    if not model.is_file():
        errors.append(f"Registered item {item_id} has no item model JSON")
    if f"item.boltrifle.{item_id}" not in lang:
        errors.append(f"Registered item {item_id} has no en_us display name")

# 3. Check every texture reference in item model JSON.
for path, doc in json_docs.items():
    if path.parent != ASSETS / "models/item" or not isinstance(doc, dict):
        continue
    for key, texture in doc.get("textures", {}).items():
        if not isinstance(texture, str) or ":" not in texture:
            continue
        namespace, resource = texture.split(":", 1)
        if namespace != "boltrifle":
            continue
        tex_path = RES / f"assets/{namespace}/textures/{resource}.png"
        if not tex_path.is_file():
            errors.append(f"Missing texture referenced by {path.name}: {texture}")

# 4. Check GeckoLib geometry, animation references, and animation bone tracks.
geo_root = ASSETS / "geo/item"
anim_root = ASSETS / "animations/item"
geometry_bones: dict[str, set[str]] = {}
for path in sorted(geo_root.glob("*.geo.json")):
    doc = json_docs.get(path)
    geometries = doc.get("minecraft:geometry", []) if isinstance(doc, dict) else []
    if not geometries:
        errors.append(f"No minecraft:geometry entry in {path.name}")
        continue
    geometry_bones[path.name.removesuffix(".geo.json")] = {
        bone.get("name") for geometry in geometries for bone in geometry.get("bones", [])
        if isinstance(bone, dict) and isinstance(bone.get("name"), str)
    }
for path in sorted(anim_root.glob("*.animation.json")):
    doc = json_docs.get(path)
    if not isinstance(doc, dict):
        continue
    weapon = path.name.removesuffix(".animation.json")
    bones = geometry_bones.get(weapon)
    for anim_name, anim in doc.get("animations", {}).items():
        if not isinstance(anim, dict):
            errors.append(f"Malformed animation {anim_name} in {path.name}")
            continue
        if bones is not None:
            for bone_name in anim.get("bones", {}):
                if bone_name not in bones:
                    errors.append(f"Animation {anim_name} references missing bone '{bone_name}' in {weapon}.geo.json")

# 5. Check sound event definitions point to actual OGG files.
sound_path = ASSETS / "sounds.json"
sounds = json_docs.get(sound_path, {})
if isinstance(sounds, dict):
    for event, spec in sounds.items():
        for sound in spec.get("sounds", []) if isinstance(spec, dict) else []:
            sound_name = sound.get("name", "") if isinstance(sound, dict) else sound
            if not isinstance(sound_name, str) or ":" not in sound_name:
                errors.append(f"Malformed sound entry in event {event}: {sound_name!r}")
                continue
            namespace, name = sound_name.split(":", 1)
            sound_file = RES / f"assets/{namespace}/sounds/{name}.ogg"
            if not sound_file.is_file():
                errors.append(f"Sound event {event} references missing file {sound_file.relative_to(ROOT)}")

# 6. Static gameplay safety checks for reload/bolt-cycle state transitions.
firearm_source = (ROOT / "src/main/java/com/example/boltrifle/FirearmItem.java").read_text(encoding="utf-8")
rifle_source = (ROOT / "src/main/java/com/example/boltrifle/RifleItem.java").read_text(encoding="utf-8")
mod_source = source
if "BoltRifleMod.isReloading(stack)" not in firearm_source:
    errors.append("FirearmItem.use lacks a reload-in-progress guard")
if "BoltRifleMod.isReloading(stack)" not in rifle_source:
    errors.append("RifleItem.use lacks a reload-in-progress guard")
if "BoltRifleMod.isBoltCycling(stack)" not in rifle_source:
    errors.append("RifleItem.use lacks a bolt-cycle guard")
if "boolean boltAction = \"bolt_rifle\".equals(weapon.getGeoName())" not in mod_source:
    errors.append("Reload sound staging lacks the M700 internal-magazine sound variant")

# 7. Check the detachable-magazine implementation stays wired into firearm reloads.
magazine_source = (ROOT / "src/main/java/com/example/boltrifle/MagazineItem.java").read_text(encoding="utf-8")
if "BoltRifleMod.MAG_LOADED" not in magazine_source:
    errors.append("MagazineItem does not persist its own round count")
if "ammoItem.get()" not in magazine_source:
    errors.append("MagazineItem does not validate matching ammunition")
if "ejectMagazine(player, stack, (FirearmItem) weapon)" not in mod_source:
    errors.append("Reload timeline does not eject the currently loaded magazine")
if "stack.set(LOADED.get(), Math.min(((FirearmItem) weapon).getMagazineCapacity(), pending))" not in mod_source:
    errors.append("Reload timeline does not insert the reserved magazine round count")
expected_magazine_links = {
    '"ak47", "ak47", "ak47", () -> MAG_AK.get()': "AK-47 magazine compatibility",
    '"glock19", "glock19", "glock19", () -> MAG_GLOCK19.get()': "Glock 19 magazine compatibility",
    '"m14ebr", "m14ebr", "m14ebr", () -> MAG_M14.get()': "M14 EBR magazine compatibility",
    '"m4a1", "m4a1", "m4a1", () -> MAG_STANAG.get()': "M4A1/STANAG magazine compatibility",
    '"mini14", "mini14", "mini14", () -> MAG_MINI14.get()': "Mini-14 magazine compatibility",
    '"mp7", "mp7", "mp7", () -> MAG_MP7.get()': "MP7 magazine compatibility",
    '"p90", "p90", "p90", () -> MAG_P90.get()': "P90 magazine compatibility",
    '"sks", "sks", "sks", () -> MAG_SKS.get()': "SKS magazine compatibility",
}
for snippet, description in expected_magazine_links.items():
    if snippet not in mod_source:
        errors.append(f"Missing {description}")

# 8. Check recipe results/ingredients against registered mod items (vanilla and tags are allowed).
for path in sorted((RES / "data/boltrifle/recipe").glob("*.json")):
    doc = json_docs.get(path)
    if not isinstance(doc, dict):
        continue
    result = doc.get("result")
    if isinstance(result, dict):
        item_id = result.get("id") or result.get("item")
        if isinstance(item_id, str) and item_id.startswith("boltrifle:") and item_id.split(":", 1)[1] not in registered:
            errors.append(f"Recipe {path.name} produces unregistered item {item_id}")
    ingredients = list(doc.get("ingredients", []))
    if isinstance(doc.get("key"), dict):
        ingredients.extend(doc["key"].values())
    if isinstance(doc.get("ingredient"), dict):
        ingredients.append(doc["ingredient"])
    for ingredient in ingredients:
        if not isinstance(ingredient, dict):
            continue
        item_id = ingredient.get("item")
        if isinstance(item_id, str) and item_id.startswith("boltrifle:") and item_id.split(":", 1)[1] not in registered:
            errors.append(f"Recipe {path.name} uses unregistered item {item_id}")

print(f"Checked {checks} JSON files, {len(registered)} registered item IDs, "
      f"{len(geometry_bones)} geometry models, and sound/recipe references.")
if errors:
    print(f"FAILED: {len(errors)} issue(s)")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)
print("PASS: no broken resource references found.")
print("Note: this does not verify Java compilation or in-game behavior.")
