package com.example.boltrifle;

import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.sounds.SoundSource;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(BoltRifleMod.MOD_ID)
public class BoltRifleMod {
    public static final String MOD_ID = "boltrifle";
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, MOD_ID);
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT = sound("shot");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT_HEAVY = sound("shot_heavy");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT_LIGHT = sound("shot_light");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT_SUPP = sound("shot_supp");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT_HEAVY_SUPP = sound("shot_heavy_supp");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOT_LIGHT_SUPP = sound("shot_light_supp");
    public static final DeferredHolder<SoundEvent, SoundEvent> CLICK = sound("click");
    public static final DeferredHolder<SoundEvent, SoundEvent> CLICK_DRY = sound("click_dry");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOLT_OPEN = sound("bolt_open");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOLT_CLOSE = sound("bolt_close");
    public static final DeferredHolder<SoundEvent, SoundEvent> MAG_OUT = sound("mag_out");
    public static final DeferredHolder<SoundEvent, SoundEvent> MAG_IN = sound("mag_in");
    public static final DeferredHolder<SoundEvent, SoundEvent> RACK = sound("rack");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHELL = sound("shell");

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> LOADED =
            intComponent("loaded", 0, 50);
    /** Rounds physically stored in an inventory magazine item. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> MAG_LOADED =
            intComponent("mag_loaded", 0, 100);
    // Temporary reload state is stored on the weapon stack so it survives inventory movement.
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> RELOAD_TICKS_LEFT =
            intComponent("reload_ticks_left", 0, 200);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> RELOAD_DURATION =
            intComponent("reload_duration", 0, 200);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> RELOAD_PENDING =
            intComponent("reload_pending", 0, 50);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> RELOAD_SOUND_MASK =
            intComponent("reload_sound_mask", 0, 7);
    // Bolt-cycle audio is a separate timeline from reloads, so its clicks can follow the fire animation.
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> BOLT_TICKS_LEFT =
            intComponent("bolt_ticks_left", 0, 200);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> BOLT_DURATION =
            intComponent("bolt_duration", 0, 200);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> BOLT_SOUND_MASK =
            intComponent("bolt_sound_mask", 0, 3);

    private static DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> intComponent(
            String id, int min, int max) {
        return COMPONENTS.register(id, () -> DataComponentType.<Integer>builder()
                .persistent(Codec.intRange(min, max))
                .networkSynchronized(ByteBufCodecs.VAR_INT).build());
    }

    // The original animated bolt-action rifle retains the existing prototype firing/reload logic.
    public static final DeferredItem<Item> BOLT_RIFLE = ITEMS.register("bolt_rifle",
            () -> new RifleItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> RIFLE_ROUND = item("rifle_round");

    // Restored item catalogue from the supplied compiled mod.
    public static final DeferredItem<Item> AK47 = firearm("ak47", "ak47", "ak47", () -> MAG_AK.get(), 30, 10.0f, 64.0, 4, SHOT::get);
    public static final DeferredItem<Item> GLOCK19 = firearm("glock19", "glock19", "glock19", () -> MAG_GLOCK19.get(), 15, 8.0f, 40.0, 8, SHOT_LIGHT::get);
    public static final DeferredItem<Item> M14EBR = firearm("m14ebr", "m14ebr", "m14ebr", () -> MAG_M14.get(), 20, 14.0f, 90.0, 10, SHOT_HEAVY::get);
    public static final DeferredItem<Item> M4A1 = firearm("m4a1", "m4a1", "m4a1", () -> MAG_STANAG.get(), 30, 9.0f, 70.0, 3, SHOT_LIGHT::get);
    public static final DeferredItem<Item> MINI14 = firearm("mini14", "mini14", "mini14", () -> MAG_MINI14.get(), 20, 10.0f, 65.0, 6, SHOT_LIGHT::get);
    public static final DeferredItem<Item> MP7 = firearm("mp7", "mp7", "mp7", () -> MAG_MP7.get(), 40, 7.0f, 50.0, 3, SHOT_LIGHT::get);
    public static final DeferredItem<Item> P90 = firearm("p90", "p90", "p90", () -> MAG_P90.get(), 50, 8.0f, 55.0, 3, SHOT_LIGHT::get);
    public static final DeferredItem<Item> SKS = firearm("sks", "sks", "sks", () -> MAG_SKS.get(), 10, 13.0f, 80.0, 9, SHOT_HEAVY::get);

    public static final DeferredItem<Item> ACOG = geo("acog", "att_acog", "att_acog");
    public static final DeferredItem<Item> FLASH_HIDER = geo("flash_hider", "att_flash_hider", "att_flash_hider");
    public static final DeferredItem<Item> HOLO = geo("holo", "att_holo", "att_holo");
    public static final DeferredItem<Item> MUZZLE_BRAKE = geo("muzzle_brake", "att_muzzle_brake", "att_muzzle_brake");
    public static final DeferredItem<Item> RED_DOT = geo("red_dot", "att_red_dot", "att_red_dot");
    public static final DeferredItem<Item> SCOPE = geo("scope", "att_scope", "att_scope");
    public static final DeferredItem<Item> SUPPRESSOR = geo("suppressor", "att_suppressor", "att_suppressor");

    public static final DeferredItem<Item> AMMO_223_REM = item("ammo_223_rem");
    public static final DeferredItem<Item> AMMO_308_WIN = item("ammo_308_win");
    public static final DeferredItem<Item> AMMO_46X30 = item("ammo_46x30");
    public static final DeferredItem<Item> AMMO_556X45_NATO = item("ammo_556x45_nato");
    public static final DeferredItem<Item> AMMO_57X28 = item("ammo_57x28");
    public static final DeferredItem<Item> AMMO_762X39 = item("ammo_762x39");
    public static final DeferredItem<Item> AMMO_762X51_NATO = item("ammo_762x51_nato");
    public static final DeferredItem<Item> AMMO_9X19 = item("ammo_9x19");

    public static final DeferredItem<Item> MAG_M700 = item("mag_m700");
    // Detachable magazines carry their own round count and only accept their matching caliber.
    public static final DeferredItem<MagazineItem> MAG_SKS = magazine("mag_sks", () -> AMMO_762X39.get(), 10);
    public static final DeferredItem<MagazineItem> MAG_AK = magazine("mag_ak", () -> AMMO_762X39.get(), 30);
    public static final DeferredItem<MagazineItem> MAG_M14 = magazine("mag_m14", () -> AMMO_762X51_NATO.get(), 20);
    public static final DeferredItem<MagazineItem> MAG_MINI14 = magazine("mag_mini14", () -> AMMO_223_REM.get(), 20);
    public static final DeferredItem<MagazineItem> MAG_STANAG = magazine("mag_stanag", () -> AMMO_556X45_NATO.get(), 30);
    public static final DeferredItem<MagazineItem> MAG_P90 = magazine("mag_p90", () -> AMMO_57X28.get(), 50);
    public static final DeferredItem<MagazineItem> MAG_MP7 = magazine("mag_mp7", () -> AMMO_46X30.get(), 40);
    public static final DeferredItem<MagazineItem> MAG_GLOCK19 = magazine("mag_glock19", () -> AMMO_9X19.get(), 15);
    public static final DeferredItem<Item> GRENADE = item("grenade");

    private static DeferredHolder<SoundEvent, SoundEvent> sound(String id) {
        ResourceLocation location = ResourceLocation.fromNamespaceAndPath(MOD_ID, id);
        return SOUNDS.register(id, () -> SoundEvent.createVariableRangeEvent(location));
    }

    private static DeferredItem<Item> item(String id) {
        return ITEMS.register(id, () -> new Item(new Item.Properties()));
    }

    private static DeferredItem<Item> firearm(String id, String geoName, String textureName,
            Supplier<? extends MagazineItem> magazine, int capacity, float damage, double range, int cooldown, Supplier<SoundEvent> sound) {
        return ITEMS.register(id, () -> new FirearmItem(new Item.Properties(), geoName, textureName,
                magazine, capacity, damage, range, cooldown, sound));
    }

    private static DeferredItem<MagazineItem> magazine(String id, Supplier<? extends Item> ammo, int capacity) {
        return ITEMS.register(id, () -> new MagazineItem(new Item.Properties().stacksTo(1), ammo, capacity));
    }

    private static DeferredItem<Item> geo(String id, String geoName, String textureName) {
        return ITEMS.register(id, () -> new GeoModelItem(new Item.Properties(), geoName, textureName));
    }

    public BoltRifleMod(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        COMPONENTS.register(modEventBus);
        SOUNDS.register(modEventBus);
        modEventBus.addListener(this::addToCreativeTab);
        NeoForge.EVENT_BUS.addListener(this::onPlayerTick);
    }


    /** True while this stack has a server-owned reload in progress. */
    public static boolean isReloading(ItemStack stack) {
        return stack.getOrDefault(RELOAD_TICKS_LEFT.get(), 0) > 0;
    }

    /** True while the M700's bolt-cycle animation/audio timeline is still active. */
    public static boolean isBoltCycling(ItemStack stack) {
        return stack.getOrDefault(BOLT_TICKS_LEFT.get(), 0) > 0;
    }

    /** Starts a reload timeline. Ammunition is committed at the magazine-in beat, not at click time. */
    public static void beginReload(ItemStack stack, int roundsToLoad, int duration) {
        stack.set(RELOAD_PENDING.get(), roundsToLoad);
        stack.set(RELOAD_DURATION.get(), duration);
        stack.set(RELOAD_TICKS_LEFT.get(), duration);
        stack.set(RELOAD_SOUND_MASK.get(), 0);
    }

    private void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) return;

        // A stack can be visible through both the selected slot and the main hand; identity-dedupe it.
        Set<ItemStack> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        for (ItemStack stack : player.getInventory().items) {
            if (seen.add(stack)) tickReload(player, stack);
        }
        ItemStack offhand = player.getOffhandItem();
        if (seen.add(offhand)) tickReload(player, offhand);
    }

    private void tickReload(Player player, ItemStack stack) {
        if (!(stack.getItem() instanceof GeoModelItem weapon)) return;
        tickBoltCycle(player, stack, weapon);

        int left = stack.getOrDefault(RELOAD_TICKS_LEFT.get(), 0);
        if (left <= 0) return;

        int duration = Math.max(1, stack.getOrDefault(RELOAD_DURATION.get(), left));
        int elapsed = duration - left + 1;
        int mask = stack.getOrDefault(RELOAD_SOUND_MASK.get(), 0);
        int pending = stack.getOrDefault(RELOAD_PENDING.get(), 0);
        int magOutBeat = Math.max(2, Math.round(duration * 0.20f));
        int magInBeat = Math.max(magOutBeat + 2, Math.round(duration * 0.48f));
        int actionBeat = Math.max(magInBeat + 2, Math.round(duration * 0.78f));

        boolean boltAction = "bolt_rifle".equals(weapon.getGeoName());
        boolean detachableMagazine = weapon instanceof FirearmItem;
        if (elapsed >= magOutBeat && (mask & 1) == 0) {
            if (boltAction) {
                playAtPlayer(player, BOLT_OPEN.get(), 0.8f, 1.0f);
            } else if (detachableMagazine) {
                ejectMagazine(player, stack, (FirearmItem) weapon);
                playAtPlayer(player, MAG_OUT.get(), 0.8f, 1.0f);
            }
            mask |= 1;
        }
        if (elapsed >= magInBeat && (mask & 2) == 0) {
            if (detachableMagazine) {
                // The reserved round count came from a real compatible magazine consumed at
                // reload start. The old magazine was returned to inventory at the mag-out beat.
                stack.set(LOADED.get(), Math.min(((FirearmItem) weapon).getMagazineCapacity(), pending));
                playAtPlayer(player, MAG_IN.get(), 0.8f, 1.0f);
            } else {
                int loaded = stack.getOrDefault(LOADED.get(), 0);
                stack.set(LOADED.get(), Math.min(5, loaded + pending));
                // The M700 has an internal magazine; this click represents feeding rounds.
                playAtPlayer(player, CLICK.get(), 0.8f, 1.0f);
            }
            stack.set(RELOAD_PENDING.get(), 0);
            mask |= 2;
        }
        if (elapsed >= actionBeat && (mask & 4) == 0) {
            SoundEvent actionSound = boltAction ? BOLT_CLOSE.get() : RACK.get();
            playAtPlayer(player, actionSound, 0.75f, 1.0f);
            mask |= 4;
        }

        int nextLeft = Math.max(0, left - 1);
        stack.set(RELOAD_SOUND_MASK.get(), mask);
        stack.set(RELOAD_TICKS_LEFT.get(), nextLeft);
        if (nextLeft == 0) {
            // Safety net: never lose the reserved rounds if a stage was skipped for any reason.
            int stillPending = stack.getOrDefault(RELOAD_PENDING.get(), 0);
            if (stillPending > 0) {
                if (weapon instanceof FirearmItem firearm) {
                    if ((mask & 1) == 0) ejectMagazine(player, stack, firearm);
                    stack.set(LOADED.get(), Math.min(firearm.getMagazineCapacity(), stillPending));
                } else {
                    int loaded = stack.getOrDefault(LOADED.get(), 0);
                    stack.set(LOADED.get(), Math.min(5, loaded + stillPending));
                }
            }
            stack.set(RELOAD_PENDING.get(), 0);
            stack.set(RELOAD_DURATION.get(), 0);
            stack.set(RELOAD_SOUND_MASK.get(), 0);
        }
    }

    private static void ejectMagazine(Player player, ItemStack weaponStack, FirearmItem firearm) {
        int rounds = weaponStack.getOrDefault(LOADED.get(), 0);
        ItemStack magazine = new ItemStack(firearm.getMagazineItem());
        magazine.set(MAG_LOADED.get(), Math.max(0, Math.min(firearm.getMagazineCapacity(), rounds)));
        weaponStack.set(LOADED.get(), 0);
        if (!player.getInventory().add(magazine)) {
            player.drop(magazine, false);
        }
    }

    /** Starts the M700's mechanical cycle audio without blocking its already-running fire animation. */
    public static void beginBoltCycle(ItemStack stack, int duration) {
        stack.set(BOLT_TICKS_LEFT.get(), duration);
        stack.set(BOLT_DURATION.get(), duration);
        stack.set(BOLT_SOUND_MASK.get(), 0);
    }

    private void tickBoltCycle(Player player, ItemStack stack, GeoModelItem weapon) {
        int left = stack.getOrDefault(BOLT_TICKS_LEFT.get(), 0);
        if (left <= 0 || !"bolt_rifle".equals(weapon.getGeoName())) return;

        int duration = Math.max(1, stack.getOrDefault(BOLT_DURATION.get(), left));
        int elapsed = duration - left + 1;
        int mask = stack.getOrDefault(BOLT_SOUND_MASK.get(), 0);
        int openBeat = Math.max(1, Math.round(duration * 0.34f));
        int closeBeat = Math.max(openBeat + 1, Math.round(duration * 0.72f));

        if (elapsed >= openBeat && (mask & 1) == 0) {
            playAtPlayer(player, BOLT_OPEN.get(), 0.8f, 1.0f);
            mask |= 1;
        }
        if (elapsed >= closeBeat && (mask & 2) == 0) {
            playAtPlayer(player, BOLT_CLOSE.get(), 0.8f, 1.0f);
            mask |= 2;
        }

        int nextLeft = Math.max(0, left - 1);
        stack.set(BOLT_SOUND_MASK.get(), mask);
        stack.set(BOLT_TICKS_LEFT.get(), nextLeft);
        if (nextLeft == 0) {
            stack.set(BOLT_DURATION.get(), 0);
            stack.set(BOLT_SOUND_MASK.get(), 0);
        }
    }

    private static void playAtPlayer(Player player, SoundEvent sound, float volume, float pitch) {
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), sound,
                SoundSource.PLAYERS, volume, pitch);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT || event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            for (DeferredItem<?> item : ITEMS.getEntries()) {
                event.accept(item.get());
            }
        }
    }
}
