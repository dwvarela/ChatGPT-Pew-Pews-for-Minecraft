package com.example.boltrifle;

import java.util.function.Consumer;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.SingletonGeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.renderer.GeoRenderProvider;
import software.bernie.geckolib.util.GeckoLibUtil;

/** An item rendered from the original mod's Blockbench/GeckoLib geometry. */
public class GeoModelItem extends Item implements GeoItem {
    private final String geoName;
    private final String textureName;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public GeoModelItem(Properties properties, String geoName, String textureName) {
        super(properties.stacksTo(1));
        this.geoName = geoName;
        this.textureName = textureName;
        SingletonGeoAnimatable.registerSyncedAnimatable(this);
    }

    public String getGeoName() {
        return geoName;
    }

    public String getTextureName() {
        return textureName;
    }

    private static final java.util.Set<String> ANIMATED_WEAPONS = java.util.Set.of(
            "bolt_rifle", "ak47", "glock19", "m14ebr", "m4a1", "mini14", "mp7", "p90", "sks");
    private static final java.util.Set<String> LAST_SHOT_ANIMATIONS = java.util.Set.of(
            "glock19", "m14ebr", "m4a1", "mini14", "mp7", "p90", "sks");
    private static final java.util.Set<String> RELOAD_RELEASE_ANIMATIONS = java.util.Set.of(
            "glock19", "m14ebr", "m4a1", "mini14", "mp7", "p90", "sks");

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        if (!ANIMATED_WEAPONS.contains(geoName)) {
            return;
        }

        AnimationController<GeoModelItem> controller = new AnimationController<>(this, "weapon", 0, state ->
                state.setAndContinue(RawAnimation.begin().thenLoop(animation("idle"))));

        controller.triggerableAnim("fire", RawAnimation.begin().thenPlay(animation("fire")));
        controller.triggerableAnim("dryfire", RawAnimation.begin().thenPlay(animation("dryfire")));
        controller.triggerableAnim("reload", RawAnimation.begin().thenPlay(animation("reload")));
        controller.triggerableAnim("reload_chamber", RawAnimation.begin().thenPlay(animation("reload_chamber")));
        if (LAST_SHOT_ANIMATIONS.contains(geoName)) {
            controller.triggerableAnim("fire_last", RawAnimation.begin().thenPlay(animation("fire_last")));
        }
        if (RELOAD_RELEASE_ANIMATIONS.contains(geoName)) {
            controller.triggerableAnim("reload_release", RawAnimation.begin().thenPlay(animation("reload_release")));
        }
        controllers.add(controller);
    }

    private String animation(String state) {
        return "animation." + geoName + "." + state;
    }

    /** Starts a synced animation for the specific weapon stack, on the server. */
    public void triggerWeaponAnimation(Level level, Player player, ItemStack stack, String state) {
        if (!(level instanceof ServerLevel serverLevel) || !ANIMATED_WEAPONS.contains(geoName)) {
            return;
        }
        if ("fire_last".equals(state) && !LAST_SHOT_ANIMATIONS.contains(geoName)) {
            state = "fire";
        }
        if ("reload_release".equals(state) && !RELOAD_RELEASE_ANIMATIONS.contains(geoName)) {
            state = "reload_chamber";
        }
        triggerAnim(player, GeoItem.getOrAssignId(stack, serverLevel), "weapon", state);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            private GeoItemRenderer<GeoModelItem> renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getGeoItemRenderer() {
                if (renderer == null) {
                    renderer = new GeoItemRenderer<>(new GeoItemModel());
                }
                return renderer;
            }
        });
    }

    private class GeoItemModel extends software.bernie.geckolib.model.GeoModel<GeoModelItem> {
        @Override
        public ResourceLocation getModelResource(GeoModelItem animatable) {
            return ResourceLocation.fromNamespaceAndPath(BoltRifleMod.MOD_ID, "geo/item/" + geoName + ".geo.json");
        }

        @Override
        public ResourceLocation getTextureResource(GeoModelItem animatable) {
            return ResourceLocation.fromNamespaceAndPath(BoltRifleMod.MOD_ID, "textures/item/" + textureName + ".png");
        }

        @Override
        public ResourceLocation getAnimationResource(GeoModelItem animatable) {
            return ResourceLocation.fromNamespaceAndPath(BoltRifleMod.MOD_ID, "animations/item/" + geoName + ".animation.json");
        }
    }
}
